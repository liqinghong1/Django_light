package cn.leancloud.leanstoragegettingstarted;

import android.app.Application;

import cn.leancloud.AVLogger;
import cn.leancloud.AVOSCloud;


/**
 * Created by BinaryHB on 16/9/13.
 */
public class GettingStartedApp extends Application {

  @Override
  public void onCreate() {
    super.onCreate();
    //开启调试日志
    AVOSCloud.setLogLevel(AVLogger.Level.DEBUG);
    AVOSCloud.initialize(this,"Tw46rc3a7wUYt2yUseqzOvnQ-gzGzoHsz", "nutcv1SGRMNCQ2MWMtVE9sVP","https://tw46rc3a.lc-cn-n1-shared.com");

  }
}
